export const BOX = "BOX";
export const PALETTE = "PALETTE";
export const PATTERN = "PATTERN";
export const SCALE = "SCALE";
